﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace NoFlapBird
{
    class Player
    {
        Texture2D texture;
        public Vector2 position, velocity, acceleration, center;
        float rotation;

        //Konstruktor
        public Player(Texture2D texture)
        {
            this.texture = texture;
            position = new Vector2(0, 400);
            velocity = new Vector2(0, 0);
            acceleration = new Vector2(1, 0);

            center = new Vector2(texture.Width / 2, texture.Height / 2);
        }
        
        public Rectangle Hitbox
        {
            get
            {
                Rectangle hitbox = new Rectangle();
                hitbox.Location = position.ToPoint();

                hitbox.Width = texture.Width;
                hitbox.Height = texture.Height;

                return hitbox;
            }
        }

        public void Update()
        {
            //Spelare får acceleration

            velocity += acceleration;

            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                velocity.X = 0;
            }


            //Fågeln rör sig
            position += velocity;
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            //            spriteBatch.Draw(texture, position, Color.White);

            spriteBatch.Draw(texture, position, null,
                Color.White, rotation, center,
                1, SpriteEffects.None, 1);
        }
    }
}
